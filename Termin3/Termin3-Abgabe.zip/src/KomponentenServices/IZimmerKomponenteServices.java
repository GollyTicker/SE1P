package KomponentenServices;
import FachlicheTypen.PreisTyp;
import FachlicheTypen.ZimmerNrTyp;

public interface IZimmerKomponenteServices {

	PreisTyp berechnePreis(ZimmerNrTyp zimmerNr);

}
